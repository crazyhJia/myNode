
 function render(res,data,type='') {
    res.writeHead(200, {"Content-Type": `${type?type:"application/json"};charset=utf8`})
    res.write(data);
    res.end();
}

const apiRouter = {
    '/api/data': (req,res) => {
        let myurl = new URL(req.url, 'http://127.0.0.1');
        console.log(myurl.searchParams.get('username'))
        render(res, `{ok: 123}`)
    },
    '/api/getLogin': (req,res) => {
        let myurl = new URL(req.url, 'http://127.0.0.1');
        if(myurl.searchParams.get('username') === 'rose' &&
            myurl.searchParams.get('password') === 'aaa') {
            render(res, `{'ok': 对了}`)
        } else{
            render(res, `{'ok': 错了}`)
        }
    },
    '/api/postLogin': (req,res) => {
        let myurl = new URL(req.url, 'http://127.0.0.1');
        let post = ''
        req.on('data',chunk => {
            post += chunk;
        })
        req.on('end', () => {
            post = JSON.parse(decodeURIComponent(post));
            if(post.username === 'rose' && post.password === 'aaa') {
                render(res, 'ok')
            } else{
                render(res, 'error')
            }
        })
    }
}

module.exports = apiRouter
