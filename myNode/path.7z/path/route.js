let fs = require('fs')
// function route(myurl, res) {
//     switch(myurl) {
//         case '/login':
//             res.writeHead(200, {'Content-Type':'text/html;charset=utf8'})
//             res.write(fs.readFileSync('./path/static/login.html'),'utf-8')  //同步
//             break;
//         case '/home':
//             res.writeHead(200, {'Content-Type':'text/html;charset=utf8'})
//             res.write(fs.readFileSync("./path/static/home.html"),'utf-8')
//             break;
//         default:
//             res.writeHead(404, {'Content-Type':'text/html;charset=utf8'})
//             res.write(fs.readFileSync('./path/static/404.html'),'utf-8')
//             break;
//     }
// }



//优化版
const route = {
    '/login': (req,res) => {
        render(res, './path/static/login.html')
        // res.writeHead(200, {'Content-Type':'text/html;charset=utf8'})
        // res.write(fs.readFileSync('./path/static/login.html'),'utf-8')  //同步
    },
    '/home': (req,res) => {
        render(res, './path/static/home.html')
        // res.writeHead(200, {'Content-Type':'text/html;charset=utf8'})
        // res.write(fs.readFileSync("./path/static/home.html"),'utf-8')
    },
    '/404': (req,res) => {
        res.writeHead(404, {'Content-Type':'text/html;charset=utf8'})
        res.write(fs.readFileSync('./path/static/404.html'),'utf-8')
    },
    '/favicon.ico': (req,res) => {
        //读取的本地图标
        res.writeHead(200, {'Content-Type':'image/x-icon;charset=utf8'})
        res.write(fs.readFileSync('./path/static/favicon.ico'))
    }
}

function render(res, path) {
    res.writeHead(200, {'Content-Type':'text/html;charset=utf8'})
    res.write(fs.readFileSync(path),'utf-8')
}


module.exports = route
